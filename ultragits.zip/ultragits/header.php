<!-- Start Navigation -->
<nav class="navbar mobile-sidenav navbar-sticky navbar-default validnavs navbar-fixed white no-background">

<!-- Start Top Search -->
<div class="top-search">
    <div class="container-xl">
        <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-search"></i></span>
            <input type="text" class="form-control" placeholder="Search">
            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
        </div>
    </div>
</div>
<!-- End Top Search -->

<div class="container d-flex justify-content-between align-items-center">


    <!-- Start Header Navigation -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="index.php">
            <img src="assets/img/logo-removebg-preview.png"
  class="logo logo-display" alt="Logo">
            <img src="assets/img/logo-removebg-preview.png" class="logo logo-scrolled" alt="Logo">
        </a>
    </div>
    <!-- End Header Navigation -->

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="navbar-menu">

        <img src="https://www.ultragits.com/assets/img/logo.jpg" alt="Logo">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
            <i class="fa fa-times"></i>
        </button>

        <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
            <li class="dropdown">
                <a href="index.php"  style="color:black;">Home</a>

            </li>
            <li class="dropdown megamenu-fw">
                <a href="SERVICES.PHP" class="dropdown-toggle" data-toggle="dropdown" style="color:black;">Services</a>
                <ul class="dropdown-menu megamenu-content" role="menu">
                    <li>
                        <div class="row">
                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#1A73E8;">Digital Marketing📈 </h6>
                                <div class="content">
                                    <ul class="menu-col">
                                    <li><a href="seo.html">Search Engine Optimization (SEO)</a></li>
<li><a href="sem.html">Search Engine Marketing (SEM)</a></li>
<li><a href="smo.html">Social Media Optimization (SMO)</a></li>
<li><a href="smm.html">Social Media Marketing (SMM)</a></li>
<li><a href="email-marketing.html">Email Marketing</a></li>
<li><a href="content-marketing.html">Content Marketing</a></li>
<li><a href="branding-solutions.html">Branding Solutions</a></li>

                                    </ul>
                                </div>
                            </div>
                            <!-- end col-3 -->
                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#FF5722;">Mobile App Development 📱</h6>
                                <div class="content">
                                    <ul class="menu-col">
                                    <li><a href="android-app-development.html">Android Application Development</a></li>
<li><a href="hybrid-app-development.html">Hybrid Application Development</a></li>
<li><a href="native-app-development.html">Native Application Development</a></li>
<li><a href="ios-app-development.html">iOS Application Development</a></li>

                                    </ul>
                                </div>
                            </div>
                            <!-- end col-3 -->
                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#4CAF50 ;">Web Development 🌐</h6>
                                <div class="content">
                                    <ul class="menu-col">
                                    <li><a href="website-development.html">Website Development</a></li>
<li><a href="ecommerce-development.html">eCommerce Development</a></li>
<li><a href="cms-development.html">CMS Development</a></li>
<li><a href="php-website-development.html">PHP Website Development</a></li>
<li><a href="website-maintenance-support.html">Website Maintenance & Support</a></li>

                                    </ul>
                                </div>
                            </div>


                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#FFC107;">Web Application Development 🖥️ </h6>
                                <div class="content">
                                    <ul class="menu-col">
                                    <li><a href="codeigniter-technology.html">Codeigniter Technology</a></li>
<li><a href="laravel-technology.html">Laravel Technology</a></li>
<li><a href="python-web-application.html">Python Web Application</a></li>
<li><a href="flutter-application.html">Flutter Application</a></li>
<li><a href="react-application.html">React Application</a></li>
<li><a href="nodejs-application.html">Node.js Application</a></li>



                                    </ul>
                                </div>
                            </div>

                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#9C27B0;">UI/UX Design 🎨 </h6>
                                <div class="content">
                                    <ul class="menu-col">
                                    <li><a href="responsive-website-design.html">Responsive Website Design</a></li>
<li><a href="landing-page-design.html">Landing Page Design</a></li>
<li><a href="website-redesign.html">Website Redesign</a></li>
<li><a href="logo-design.html">Logo Design</a></li>
<li><a href="brochure-design.html">Brochure Design</a></li>
<li><a href="infographics.html">Infographics</a></li>


                                    </ul>
                                </div>
                            </div>


                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#E91E63;">Other Services 🧰</h6>
                                <div class="content">
                                    <ul class="menu-col">
                                        <li><a href="about-us.php">ERP Software Development</a></li>
                                        <li><a href="pricing.html">Project Management</a></li>
                                        <li><a href="contact-us.html">Internet Of Things (IOT)</a></li>
                                        <li><a href="404.php">AI Solution & Congnitive Computing</a></li>
                                        <li><a href="404.php">ACloud Consulting Service</a></li>
                                        <li><a href="404.php">Domain Name & Web Hosting</a></li>
                                    </ul>
                                </div>
                            </div>


                            <div class="col-menu col-lg-3">
                                <h6 class="title" style="color:#00BCD4;">Internship 🎓</h6>
                                <div class="content">
                                    <ul class="menu-col">
                                    <li><a href="internship-opportunities.html">Internship Opportunities</a></li>
<li><a href="internship-application.html">Apply for Internship</a></li>
<li><a href="internship-program-details.html">Program Details</a></li>

                                    </ul>

                                </div>

                            </div>


                            <div class="col-menu col-lg-3">

                            <div class="internship-image" style="margin-top: 20px;">
    <img src="assets/img/anna.webp" alt="Internship Visual" style="width: 100%; height: auto; display: block;">
</div>

                            </div>
                            <!-- end col-3 -->
                        </div>

                        <!-- end row -->
                    </li>
                </ul>
            </li>


            <li class="dropdown">
                <a href="about-us.php" class="dropdown-toggle" data-toggle="dropdown" style="color:black;">About Us</a>
                <ul class="dropdown-menu">
                    <li><a href="services-details.html">Our Story</a></li>
                    <li><a href="team.php">Teams</a></li>
                    <li><a href="services-details.html">Founder Message</a></li>
                    <li><a href="services-details.html">Our Institute</a></li>

                </ul>
            </li>


            <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:black;">Case Studies</a>
                <ul class="dropdown-menu">
                    <li><a href="blog-standard.html">Digital Marketing</a></li>
                    <li><a href="blog-standard.html">Web Application</a></li>
                    <li><a href="blog-standard.html">App Development</a></li>
                    </ul>
            </li>

            <li class="dropdown">
            <a href="contact-us.html" class="dropdown-toggle" data-toggle="dropdown" style="color:black;">Portfolio</a>
            <ul class="dropdown-menu">
                <li><a href="blog-standard.html">Digital Marketing</a></li>
                <li><a href="blog-standard.html">Web Application</a></li>
                <li><a href="blog-standard.html">App Development</a></li>
                </ul>
            </li>
            <li><a href="contact-us.php" style="color:black;">contact Us</a></li>


    <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:black;">Work With Us</a>
                <ul class="dropdown-menu">
                    <li><a href="career.php">Career</a></li>
                    <li><a href="blog-with-sidebar.html">Why Choose Us</a></li>
                    <li><a href="blog-2-colum.html">Work Environment</a></li>
                    <li><a href="blog-3-colum.html">Facilities</a></li>

                </ul>
            </li>
        </ul>
    </div>

    <!-- /.navbar-collapse -->

    <div class="attr-right">
        <!-- Start Atribute Navigation -->
        <div class="attr-nav">
            <ul>
                <li class="search"><a href="#"><i class="fas fa-search"></i></a></li>
                <li class="side-menu">
                    <a href="#">
                        <span class="bar-1"></span>
                        <span class="bar-2"></span>
                        <span class="bar-3"></span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- End Atribute Navigation -->

        <!-- Start Side Menu -->
        <div class="side">
            <a href="#" class="close-side"><i class="fas fa-times"></i>
</a>
            <div class="widget">
                <div class="logo">
                    <img src="assets/img/image.png" alt="Logo">
                </div>
                <p align="justify">
                We are a team of seasoned experts with over 10 years of experience in the digital marketing in chennai. We specialize in delivering top-quality IT software and hardware solutions, covering everything from core design to comprehensive online marketing strategies.
                </p>
            </div>
            <div class="widget address">
                <div>
                    <ul>
                        <li>
                            <div class="content">
                                <p>Address</p>
                                <strong>Faiz Manzil, 10/44, Aziz Mulk 1st St, Thousand Lights, Chennai, Tamil Nadu 600006</strong>
                            </div>
                        </li>
                        <li>
                            <div class="content">
                                <p>Email</p>
                                <strong>mail@ultragits.com</strong>
                            </div>
                        </li>
                        <li>
                            <div class="content">
                                <p>Contact</p>
                                <strong>+91-8610213611</strong>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- End Side Menu -->


    </div>
    <!-- Main Nav -->
</div>

<!-- Sticky Menu HTML -->
<div class="sticky-menu">
  <ul>
    <li>
      <a href="#home">
        <i class="fas fa-download"></i>
        <span>Download Brochure</span>
      </a>
    </li>
    <li>
      <a href="#services">
        <i class="fas fa-building"></i>
        <span>Company Details</span>
      </a>
    </li>
    <li>
      <a href="#portfolio">
        <i class="fas fa-calendar-alt"></i>
        <span>Schedule A Call</span>
      </a>
    </li>
    <li>
      <a href="#contact">
        <i class="fas fa-bell"></i>
        <span>Notice</span>
      </a>
    </li>
  </ul>
</div>

<!-- Sticky Menu CSS -->
<style>
  html {
    scroll-behavior: smooth;
  }

  .sticky-menu {
    position: fixed;
    top: 30%;
    right: 0;
    background-color: #1e3974;
    z-index: 9999;
    border-radius: 8px 0 0 8px;
    width: auto;
  }

  .sticky-menu ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }

  .sticky-menu ul li {
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  }

  .sticky-menu ul li:last-child {
    border-bottom: none;
  }

  .sticky-menu ul li a {
    display: flex;
    align-items: center;
    padding: 12px 16px;
    color: white;
    text-decoration: none;
    font-weight: 500;
    font-size: 15px;
    transition: background 0.3s ease;
    position: relative;
  }

  .sticky-menu ul li a:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }

  .sticky-menu i {
    font-size: 18px;
    min-width: 20px;
  }

  .sticky-menu ul li a span {
    margin-left: 10px;
    white-space: nowrap;
    overflow: hidden;
    max-width: 0;
    opacity: 0;
    transition: max-width 0.3s ease, opacity 0.3s ease;
  }

  .sticky-menu ul li a:hover span {
    max-width: 180px;
    opacity: 1;
  }

  /* Hide sticky menu on mobile and tablet view */
  @media (max-width: 1024px) {
    .sticky-menu {
      display: none;
    }
  }
</style>