 <!-- Start Why Choose us
    ============================================= -->
    <div class="choose-us-area bg-gray default-padding">
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-6">
                    <div class="choose-us-style-one">
                        <div class="animate-illustration">
                            <img src="assets/img/illustration/v.png" alt="illustration">
                            <div class="sub-item">
                                <img class="wow pulse" src="assets/img/illustration/v8.png" alt="illustration">
                                <img class="wow fadeInLeft" data-wow-delay="300ms" src="assets/img/illustration/s5.png" alt="illustration">
                                <img class="wow fadeInUp" src="assets/img/illustration/v1.png" alt="illustration">
                                <img class="wow fadeInDown" data-wow-delay="400ms" src="assets/img/illustration/v5.png" alt="illustration">
                                <img class="wow fadeIn" data-wow-delay="500ms" src="assets/img/illustration/v6.png" alt="illustration">
                                <img src="assets/img/illustration/v3.png" alt="illustration">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 pl-50 pl-md-15 pl-xs-15">
                    <div class="choose-us-style-one">
                        <h4 class="sub-heading">Why Choose Us</h4>
                        <h2 class="heading">Why Choose UltraGITS Digital Marketing Agency in Chennai</h2>
                        <p align="justify">
                        We have more than 20+ years of experience and 300+ satisfied clients in Chennai. We manage international clients in various countries like UAE, UK, USA, Canada, etc, and more than 200+ international clients globally. We are a dedicated agency and our top priority is the satisfaction of our client. Our experience and the numbers of our clients, speaks a lot about us. We are a team of skilled Marketers, developers and graphic designers, who work as a team to increase your brand awareness online. We have worked for various industries such as


                        </p>
                        <ul>
                            <li>
                                <div class="list-item">
                                    <div class="item">
                                        <h5>500+ Trusted Chennai Clients </h5>

                                    </div>
                                    <div class="item">
                                        <h5>Better ROI-Focused Strategy</h5>

                                    </div>

                                    <div class="item">
                                        <h5>Expert & Experienced Team</h5>

                                    </div>


                                    <div class="item">
                                        <h5>Customized Solutions</h5>

                                    </div>

                                </div>
                            </li>
                            <li>
                                <div class="progressbar">
                                    <div class="circle" data-percent="98">
                                        <strong></strong>
                                    </div>
                                    <h4>With Business Growth</h4>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Why Choose Us -->
