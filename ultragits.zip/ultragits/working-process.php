
<!-- Start Process
    ============================================= -->
    <div class="process-area text-center bg-cover   default-padding text-light" style="background-color:#1e3974;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">Work Flow</h4>
                        <h2 class="title">Our Working Process</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="process-style-one-box">
                <div class="row">
                    <!-- Single Item -->
                    <div class="col-lg-3 col-md-6 process-style-one">
                        <div class="icon">
                            <img src="assets/img/icon/planning.png" alt="Icon not found">
                            <span>01</span>
                        </div>
                        <h4>Planning</h4>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-lg-3 col-md-6 process-style-one">
                        <div class="icon">
                            <img src="assets/img/icon/market-analysis.png" alt="Icon not found">
                            <span>02</span>
                        </div>
                        <h4>Research Project</h4>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-lg-3 col-md-6 process-style-one">
                        <div class="icon">
                            <img src="assets/img/icon/goal.png" alt="Icon not found">
                            <span>03</span>
                        </div>
                        <h4>Targeting</h4>
                    </div>
                    <!-- End Single Item -->
                    <!-- Single Item -->
                    <div class="col-lg-3 col-md-6 process-style-one">
                        <div class="icon">
                            <img src="assets/img/icon/trophy.png" alt="Icon not found">
                            <span>04</span>
                        </div>
                        <h4>Final result</h4>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        </div>
    </div>
    <!-- End Process -->