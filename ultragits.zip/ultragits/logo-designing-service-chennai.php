<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Get Professional Logo Design for Your Brand in Chennai | Ultragits</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

    <style>
        .hero-section {

            display: flex;
            align-items: center;
            background-color: #f8f9fa;
        }


        .hero-text ul {
            list-style: none;
            padding: 0;
        }

        .hero-text ul li::before {
            content: "✔";
            color: black;
            margin-right: 10px;
        }





@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-15px);
  }
  60% {
    transform: translateY(-7px);
  }
}

.icon-animate {
  animation: bounce 2s infinite;
}

/* Extra purple color */
.text-purple {
  color: #6f42c1;
}
p{
    color: black;
     font-size: 18px;

}


.service-card {
  border: none;
  border-radius: 15px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.1);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.service-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}
.icon-wrapper {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  color: #fff;
  font-size: 2rem;
  animation: bounce 2s infinite;
}

/* Bounce animation */
@keyframes bounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-10px);
  }
}


.tech-icon {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  padding: 10px;
}
.tech-icon img {
  width: 96px;
  height: 96px;
  animation: float 3s ease-in-out infinite;
}
.tech-icon:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.animated-icon {
  animation: bounce 2s infinite;
}

@keyframes bounce {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-10px);
  }
}

.counter-box {
  transition: transform 0.3s ease;
}
.counter-box:hover {
  transform: translateY(-5px);
}


.icon-box {
  display: flex;
  flex-direction: column;
  align-items: center;
  animation: zoomIn 2s ease-in-out infinite alternate;
}
.flag-img {
  width: 100px;
  height: auto;
  border-radius: 8px;
  transition: transform 0.5s;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}
.flag-img:hover {
  transform: scale(1.1) rotate(5deg);
}
@keyframes zoomIn {
  from {
    transform: scale(1);
  }
  to {
    transform: scale(1.05);
  }
}


.card-category {
    position: absolute;
    top: 15px;
    right: 15px;
    background-color: #5c768d;
    color: white;
    padding: 5px 15px;
    font-weight: bold;
    text-transform: uppercase;
    font-size: 14px;
    border-radius: 20px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
}

/* Card Body Styling */
.custom-card .card-body {
    padding: 20px;
}

.card-title {
    font-size: 19px;
    font-weight: bold;

}

.card-text {
    font-size: 18px;
    color: #555;
    margin-bottom: 15px;
}
.custom-card {
    position: relative;
    border: none;
    border-radius: 12px;  /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.custom-card:hover {
    transform: translateY(-10px); /* Card lifts on hover */
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

/* Image Styling: Ensures all images are the same size */
.custom-card img {
    width: 100%; /* Ensure the image takes the full width of the card */
    height: 250px; /* Fixed height for uniformity */
    object-fit: cover; /* Ensures images cover the area without stretching */
}




    </style>
</head>

<body>



    <!-- Header
    ============================================= -->
    <header>
        <?php include 'header.php' ?>


    </header>
    <!-- End Header -->

<!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center bg-gray" style="background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Logo Designing Company In Chennai</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">Logo Designing Company In Chennai</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->


    <section class="hero-section container-fluid">
        <div class="row w-100 align-items-center">
            <div class="col-lg-6 text-center mb-4 mb-lg-0">
                <img src="assets\img\h.png" alt="domain and hosting Illustration" class="img-fluid">
            </div>
            <div class="col-lg-6 hero-text px-4"><br>
                <h2><strong>Logo Designing Company In Chennai</strong></h2>
                <p align="justify">An outstanding logo design can invite lots of your prospects to connect with your organization. Ultragits has been designing custom and unique logos for over 3 years, resulting in an increasing customer base.

A company logo is the first thing customers will notice when they are introduced to a brand or company, so it is crucial that you create a logo that stands out.
Your company will shine in the market, impressing both competitors and clients alike.</p>


            </div>
        </div>
    </section>


    <br>
<section class="py-5">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Why Choose Ultragits for Logo Designing?
</strong></h2>
    <div class="row mb-4">
      <!-- Benefit 1 -->
      <div class="col-md-4">
        <div class="p-4">
       <i class="fas fa-palette fa-2x mb-3 text-primary icon-animate"></i>
    <h5><strong>Custom and Unique Designs</strong></h5>
          <p>We create logos that reflect your brand’s individuality.</p>
        </div>
      </div>

      
      <!-- Benefit 2 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-user-tie fa-2x mb-3 text-success icon-animate"></i>
    <h5><strong>Experienced Designers</strong></h5>
          <p>Our team has over 3 years of experience in logo design.</p>
        </div>
      </div>
      <!-- Benefit 3 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-map-marker-alt fa-2x mb-3 text-warning icon-animate"></i>
    <h5><strong>Targeted for Businesses in Chennai</strong></h5>
          <p> Tailored designs that resonate with local customers.</p>
        </div>
      </div>
    </div>

    <div class="row">
      <!-- Benefit 4 -->
      <div class="col-md-4">
        <div class="p-4">
          <i class="fas fa-bullhorn fa-2x mb-3 text-danger icon-animate"></i>
    <h5><strong>Impactful Brand Representation</strong></h5>
          <p>Logos that capture the essence of your brand and attract the right audience.</p>
        </div>
      </div>
      <!-- Benefit 5 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-project-diagram fa-2x mb-3 text-info icon-animate"></i>
    <h5><strong>End-to-End Design Process</strong></h5>
          <p>We provide full support from concept to final design delivery.</p>
        </div>
      </div>
      <!-- Benefit 6 -->
      <div class="col-md-4">
        <div class="p-4">
         <i class="fas fa-wallet fa-2x mb-3 text-secondary icon-animate"></i>
    <h5><strong>Affordable Pricing Plans</strong></h5>
          <p>Get premium-quality logo designs at competitive rates without compromising on creativity or professionalism.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Include Font Awesome CDN (if not already included) -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<!-- Custom animation + extra color -->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



    <section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Our Services in Logo Designing</strong></h2>

    <div class="row mb-4">
      <!-- Service 1 -->
      <div class="col-md-6 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            
            <h3 class="card-title"><b>Designing Approach</b></h3><br>
            <div class="icon-wrapper">
              <img src="assets\img\web-design.webp" height="80"  alt="Analytics and Coverage Icon" class="icon"><br><br>
            </div>
            <p class="card-text">We clarify various aspects of Logo layout they may be unaware of, then we attempt to be aware of their opinion. This step helps to create a Logo which customer needs, and in an exceptional manner. You will get up to 6 layout designs within 4-5 working days. It is possible to give comments, suggestions and thoughts or take a notion instantly.</p>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            
            <h3 class="card-title"><b>Client Centric</b></h3><br>
            <div class="icon-wrapper">
              <img src="assets\img\client.webp" height="80"  alt="Analytics and Coverage Icon" class="icon"><br><br>
            </div>
            <p class="card-text">From begin to finish, we hold your hand during the whole process -- we will also train your staff afterwards. Our emblem editor tool lets you modify your font, text style, colours, dimensions, and design of your logo design. We suggest the ideal mixture of colours, form, engineering, and find the very best way to represent your business.</p>
          </div>
        </div>
      </div>

      <div class="col-md-6 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            
            <h3 class="card-title"><b>Limitless Logo Suggestions</b></h3><br>
            <div class="icon-wrapper">
              <img src="assets\img\logo-design.webp" height="80"  alt="Analytics and Coverage Icon" class="icon"><br><br>
            </div>
            <p class="card-text">Read pre-made templates from dozens of businesses, all hand-picked from our designers. We believe in perfection to the final detail for our client. Our greatest priority would be designing a symbol you can be pleased with. That is the reason why we do not put any limitations on the amount of changes you may make.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-4">
        <div class="card service-card h-100">
          <div class="card-body">
            
            <h3 class="card-title"><b>Reviewing, Revising and Launch</b></h3><br>
            <div class="icon-wrapper">
              <img src="assets\img\launch.webp" height="80"  alt="Analytics and Coverage Icon" class="icon"><br><br>
            </div>
            <p class="card-text">We discuss our innovative Logo design together with the customer to be aware of their opinion. We update the Logo (if desired ) according to the customer's directions. We are not happy until you're! This can be done until the customer is satisfied with the Plan. We found the Logo and moved all the rights of possession to the customer.</p>
          </div>
        </div>
      </div>

      <!-- Service 2 -->
      




  </div>
</section>



<div class="container text-center">
<!-- ======= WHY ULTRAGITS ======= -->
<section class="counts section-bg">
  <div class="container">
    <div class="section-title">
        <h2 class="mb-5"  style="padding-top:15px;"><strong>Why Clients Choose UltraGITS for Their Brand Success?</strong></h2>
    </div>
    <div class="row">

      <!-- First Column -->
      <div class="col-lg-4 col-md-6 text-center" data-aos="fade-top">
        <div class="count-box">
            <i class="fas fa-gift mb-3" style="font-size: 80px; color: #0d6efd;"></i><br><br>
          <h5><strong>Benefits</strong></h5><br>
          <p align="justify">UltraGITS delivers tailored strategies designed to enhance brand visibility and drive growth. Our innovative solutions ensure businesses .</p>
        </div>
      </div>

      <!-- Second Column -->
      <div class="col-lg-4 col-md-6 text-center" data-aos="fade-top">
        <div class="count-box">
            <i class="fas fa-thumbs-up mb-3" style="font-size: 80px; color: #198754;"></i><br><br>
          <h5><strong>100% Satisfaction Guaranteed</strong></h5><br>
          <p align="justify">We prioritize customer satisfaction by offering transparent processes and measurable outcomes. Our commitment ensures exceptional results for every project.</p>
        </div>
      </div>

      <!-- Third Column -->
      <div class="col-lg-4 col-md-6 text-center" data-aos="fade-top">
        <div class="count-box">
            <i class="fas fa-headset mb-3" style="font-size: 80px; color: #0dcaf0;"></i><br><br>
           <h5><strong>24x7 Custom Support</strong></h5><br>
          <p align="justify">With round-the-clock support, UltraGITS resolves issues quickly and efficiently. Our dedicated team is always ready to meet your unique business needs.  </p>
        </div>
      </div>

    </div>
  </div>
</section>
<!-- END WHY ULTRAGITS -->
</div>


 






<section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Our Expertise</strong></h2>
    <div class="row justify-content-center">
      <!-- GODADDY -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\adobephotoshop.webp" alt="GODADDY">
          <p class="mt-3"><b>ADOBE PHOTOSHOP</b></p>
        </div>
      </div>
      <!-- BLUE HOST -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\dreamweaver.webp" alt="BLUE HOST">
          <p class="mt-3"><b>DREAM WEAVER</b></p>
        </div>
      </div>
      <!-- HOSTGATOR -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\tailorbrand.webp" alt=" HOSTGATOR">
          <p class="mt-3"><b>TAILOR BRANDS</b></p>
        </div>
      </div>
      <!-- DREAM HOST -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\AI-icon.webp" alt="DREAM HOST">
          <p class="mt-3"><b>ADOBE ILLUSTRATOR</b></p>
        </div>
      </div>
      
      <!-- SQUARE BROTHERS -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\canva-removebg-preview.png" alt="SQUARE BROTHERS" style="width: 96px; height: 96px;">
          <p class="mt-3"><b>CANVA LOGO MAKER</b></p>
        </div>
      </div>

      <!-- AWS -->
      <div class="col-6 col-md-2 mb-4">
        <div class="tech-icon">
          <img src="assets\img\wix.png" alt="AWS">
          <p class="mt-3"><b>WIX LOGO MAKER</b></p>
        </div>
      </div>
    </div>
  </div>
</section>



<!-- Second Section -->
<?php include 'blog-content.php' ?>
<!-- Font Awesome CDN -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

<?php include 'counter.php' ?>
<!-- Include Font Awesome if not already added -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


<!-- Counter Animation Script -->
<script>
  const counters = document.querySelectorAll('.counter');
  counters.forEach(counter => {
    counter.innerText = '0';
    const updateCounter = () => {
      const target = +counter.getAttribute('data-target');
      const current = +counter.innerText;
      const increment = target / 200;

      if(current < target) {
        counter.innerText = `${Math.ceil(current + increment)}`;
        setTimeout(updateCounter, 10);
      } else {
        counter.innerText = target;
      }
    };
    updateCounter();
  });
</script>



<section class="py-5 bg" style="background-color: white;">
  <div class="container d-flex align-items-center flex-wrap">
    <!-- Left: Illustration -->
    <div class="col-lg-6 mb-4 mb-lg-0 text-center">
      <img src="assets\img\il-removebg-preview.png" alt="domain and hosting Illustration" class="img-fluid illustration-animation" style="max-width: 100%;">
    </div>

    <!-- Right: Content -->
    <div class="col-lg-6">
      <h2 class="fw-bold mb-3">Your Vision, Crafted into Identity</h2>
      <p class="mb-4">
       Your logo is more than just a symbol—it's the heartbeat of your brand. At Ultragits, we don't just design logos; we craft identities that speak your story, reflect your values, and connect with your audience. Rooted in Chennai’s vibrant spirit and culture, we help local businesses leave a lasting impression, one design at a time. Let your brand be remembered—for all the right reasons.

</p>
      <a href="contact" class="btn btn-primary" style="background-color: #1e3974;">Get Started</a>
    </div>
  </div>
</section>

<!-- Optional Animation -->

<?php include 'flag.php' ?>
 




    <?php include 'footer.php' ?>



    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>