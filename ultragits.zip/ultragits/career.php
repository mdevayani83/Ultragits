
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>Career | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

</head>

<body>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!-- Start Preloader
    ============================================= -->


    <!-- Header
    ============================================= -->
    <header>
    <?php include 'header.php' ?>


        <!-- End Navigation -->
    </header>
    <!-- End Header -->

     <!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center" style=" background-image: url(assets/img/shape/breadcrumb.png); background-color:#e6e6e6;">

        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Career </h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">Career </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start About
    ============================================= -->
<!-- Breadcrumb -->



<!-- Who We Are -->
<section class="py-5 bg-white">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6 mb-4">
        <h2 class="fw-bold">Welcome to UltraGITS Careers</h2>
        <p>
          UltraGITS is a leading IT and <strong>Digital Marketing company in Chennai</strong> providing top-notch solutions across the globe. <b>We’re not just offering jobs — we’re offering opportunities to innovate, learn, and grow.</b>
        </p>
        <p>
          We specialize in Web Development, Branding, SEO, SMM, Mobile Apps, and more. If you're driven by passion and performance, you're exactly who we're looking for.
        </p>
      </div>
      <div class="col-lg-6">
        <img src="assets/img/it.gif" class="img-fluid rounded shadow" alt="Team Work">
      </div>
    </div>
  </div>
</section>

<!-- Why Choose Us -->
<section class="py-5 bg-light">
  <div class="container text-center">
    <h2 class="fw-bold mb-4">11 Reasons Why You Should Become An <b>UltraGITSIAN</b></h2>
    <div class="row g-4">
    <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🚀 Career Growth</h5>
          <p>We promote from within and support continuous personal development.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🌍 International Projects</h5>
          <p>Collaborate on projects for clients across the globe, across industries.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>💡 Innovation Culture</h5>
          <p>We encourage new ideas and reward out-of-the-box thinking.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🎓 Learning Environment</h5>
          <p>Access to training programs, certifications, and mentorship support.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🧘‍♀️ Work-Life Balance</h5>
          <p>Flexible hours, hybrid work options, and a focus on well-being.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🏆 Recognized Excellence</h5>
          <p>Rated among the top agencies in Chennai for web and digital services.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🤝 Collaborative Culture</h5>
          <p>We believe teamwork drives the best outcomes for our clients and teams.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>💻 Latest Tech Stack</h5>
          <p>Work with modern technologies and tools across design and development.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>📈 Transparent Growth Path</h5>
          <p>Clear expectations, feedback, and KPIs to help you grow your career.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🎯 Purpose-Driven Work</h5>
          <p>Contribute to meaningful client goals that impact real businesses.</p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="p-4 bg-white border rounded shadow-sm h-100">
          <h5>🛠️ End-to-End Exposure</h5>
          <p>Be part of every phase — from ideation and design to delivery and marketing.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Job Openings -->
<section id="jobs" class="py-5 bg-white">
  <div class="container">
    <h2 class="text-center fw-bold mb-5">Join Our Faimly</h2>
    <div class="row g-4">

      <!-- Job Card 1 -->
      <div class="col-md-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
          <img src="https://cdn-icons-png.flaticon.com/512/1055/1055687.png" class="card-img-top p-4" style="height: 180px; object-fit: contain;" alt="Frontend Icon">
          <div class="card-body">
            <h5 class="card-title">Frontend Developer</h5>
            <p class="card-text">React, HTML/CSS, JavaScript. 2+ yrs exp.</p>
            <p><strong>Location:</strong> Chennai / Remote</p>
            <a href="#" class="btn btn-outline-dark bg-white w-100">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Job Card 2 -->
      <div class="col-md-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
          <img src="https://cdn-icons-png.flaticon.com/512/4149/4149674.png" class="card-img-top p-4" style="height: 180px; object-fit: contain;" alt="Marketing Icon">
          <div class="card-body">
            <h5 class="card-title">Digital Marketer</h5>
            <p class="card-text">SEO, SEM, Google Ads, Social Media.</p>
            <p><strong>Location:</strong> Hybrid / Chennai</p>
            <a href="#" class="btn btn-outline-dark bg-white w-100">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Job Card 3 -->
      <div class="col-md-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
          <img src="https://cdn-icons-png.flaticon.com/512/3833/3833923.png" class="card-img-top p-4" style="height: 180px; object-fit: contain;" alt="UI/UX Icon">
          <div class="card-body">
            <h5 class="card-title">UI/UX Designer</h5>
            <p class="card-text">Figma, Adobe XD, Prototyping & UCD.</p>
            <p><strong>Location:</strong> Remote / On-site</p>
            <a href="#" class="btn btn-outline-dark bg-white w-100">Apply Now</a>
          </div>
        </div>
      </div>

      <!-- Job Card 4 -->
      <div class="col-md-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100">
          <img src="https://cdn-icons-png.flaticon.com/512/906/906175.png" class="card-img-top p-4" style="height: 180px; object-fit: contain;" alt="Backend Icon">
          <div class="card-body">
            <h5 class="card-title">Backend Developer</h5>
            <p class="card-text">Node.js, PHP, REST APIs, MySQL.</p>
            <p><strong>Location:</strong> Chennai / Remote</p>
            <a href="#" class="btn btn-outline-dark bg-white w-100">Apply Now</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


<!-- Resume Submission CTA -->
<section class="py-5 text-center bg-light">
  <div class="container">
    <h3 class="fw-semibold mb-3">Didn't find a suitable role?</h3>
    <p class="mb-4">We’d still love to hear from you! Share your resume and we’ll get in touch when the right opportunity comes along.</p>
    <a href="mailto:careers@ultragits.com" class="btn btn-outline-dark bg-white">Send Resume</a>
  </div>
</section>



    <?php include 'footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>