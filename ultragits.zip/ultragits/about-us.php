
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Digalu - Digital Marketing Agency Template">

    <!-- ========== Page Title ========== -->
    <title>About Us | UltraGITS</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="https://www.ultragits.com/assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/elegant-icons.css" rel="stylesheet">
    <link href="assets/css/flaticon-set.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

</head>

<body>

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!-- Start Preloader
    ============================================= -->


    <!-- Header
    ============================================= -->
    <header>
    <?php include 'header.php' ?>


        <!-- End Navigation -->
    </header>
    <!-- End Header -->

     <!-- Start Breadcrumb
    ============================================= -->
    <div class="breadcrumb-area text-center"  style=" background-image: url(assets/img/shape/breadcrumb.png); background-color: #e6e6e6;">

        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>About Us</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">About</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start About
    ============================================= -->
    <div class="about-area circle-shape-right-bottom default-padding" style="background-image: url(assets/img/shape/18.png);">
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-6 pr-70 pr-md-15 pr-xs-15">
                    <div class="about-style-two">
                        <div class="thumb">
                            <img class="wow fadeInLeft" src="https://media.istockphoto.com/id/624250932/vector/chennai-skyline-with-color-landmarks-and-blue-sky.jpg?s=612x612&w=0&k=20&c=PJ9HxKsXnCyX3UwKulJlXb7lWkilrrzKOI7nTicaRXo=" alt="Image not found">
                            <div class="sub-item">
                                <img class="wow fadeInDown" data-wow-delay="300ms" src="https://img.freepik.com/free-vector/chennai-india-skyline-with-panorama-white-background-vector-illustration-business-travel-tourism-concept-with-modern-buildings-image-presentation-banner-placard-web-site_596401-24.jpg" alt="Image not found">
                                <img class="wow fadeInRight" data-wow-delay="500ms" src="assets/img/digital-marketing.svg" alt="Image not found">
                            </div>
                        </div>
                    </div>
                </div>




                <div class="col-lg-6 pl-60 pl-md-15 pl-xs-15">
                    <div class="about-style-one">
                        <h4 class="sub-heading">UltraGITS</h4>
                        <h2 class="heading">Affordable digital marketting company In Chennai</h2>
                        <p>
                            Facilisis leo vel fringilla est ullamcorper. Posuere urna nec tincidunt praesent semper feugiat nibh sed. Non pulvinar neque laoreet suspendisse interdum consectetur libero id. Ac turpis egestas maecenas pharetra convallis posuere morbi. Auctor urna nunc id cursus metus aliquam eleifend.
                        </p>
                        <blockquote>
                            We focus on quality, innovation and speed. Digalu theme is a premium digital marketting company in UK
                        </blockquote>
                        <a href="https://www.youtube.com/watch?v=owhuBrGIOsE" class="popup-youtube video-play-button with-text">
                            <div class="effect"></div>
                            <span><i class="fas fa-play"></i> OUR STORY</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End About -->

    <?php include 'clients-content.php' ?>

            <!-- Start Fun Factor -->
            <!-- <div class="fun-factor-style-one mt-60 mt-xs-50">
                <div class="item-inner">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="1800" data-speed="2000">1800</div>
                                    <div class="operator">K</div>
                                </div>
                                <span class="medium">Project Done</span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="98" data-speed="2000">98</div>
                                    <div class="operator">%</div>
                                </div>
                                <span class="medium">Positive Rating</span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="12" data-speed="2000">12</div>
                                    <div class="operator">M</div>
                                </div>
                                <span class="medium">Trusted Users</span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="35" data-speed="2000">35</div>
                                    <div class="operator">+</div>
                                </div>
                                <span class="medium">Years Of Experience</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <!-- End Fun Factor -->

        </div>
    </div>
    <!-- End Brand -->

    <!-- Start Team Area
    ============================================= -->
    <div class="team-style-one-area text-center bg-gray default-padding bottom-less">

        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">Team members</h4>
                        <h2 class="title">Expert Team Members</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row align-center">

                <div class="col-lg-12">
                    <div class="row">
                    <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/team-1.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">MOHIDEEEN</a></h4>
                                    <span>CEO & Founder</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->

                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/team-2.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">YUSUF</a></h4>
                                    <span>Co-Founder
</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->

                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/ravi.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">Ravi Kumar</a></h4>
                                    <span>CTO</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->

                        <!-- Single Item -->
                        <div class="team-style-one col-xl-3 col-md-6">
                            <div class="team-style-one-item">
                                <div class="thumb">
                                    <img src="assets/img/sufiyan.webp" alt="Image not found">
                                    <ul class="social">

                                        <li class="twitter">
                                            <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="info">
                                    <h4><a href="team-details.html">Mr Sufiyan</a></h4>
                                    <span>BDM</span>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- End Team Area -->


    <!-- Start Why Choose us
    ============================================= -->
    <?php include 'why-choose-us.php' ?>
    <!-- End Why Choose Us -->

    <!-- Start Testimonials
    ============================================= -->
    <?php include 'testimonial-content.php' ?>
    <!-- End Testimonials -->


    <?php include 'footer.php' ?>

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/modernizr.custom.13711.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/circle-progress.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.scrolla.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/TweenMax.min.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>