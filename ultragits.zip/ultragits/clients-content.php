 <!-- Start Brand
    ============================================= -->
    <div class="brand-area pt-200 pt-xs-80 pt-md-120 pb-200 pb-xs-110 pb-md-170 text-light  " style="background-color:#1e3974;">
        <div class="shape-left-bottom-center">
            <img src="assets/img/shape/39.png" alt="Image Not Found">
        </div>
        <div class="curve-top">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" fill="#ffffff">
                <path d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path>
            </svg>
        </div>
        <div class="container">

            <!-- Start Brand-->
            <div class="brand-items">
                <div class="row align-center">
                    <div class="col-lg-4">
                        <h2>UltraGITS Trusted By</h2>
                        <h4>Over <strong>10+</strong> country all over the world</h4>
                    </div>
                    <div class="col-lg-8">
                        <div class="brand3col swiper">
                            <!-- Additional required wrapper -->
                            <div class="swiper-wrapper">
                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <img src="https://www.ultragits.com/assets/img/clients/careerlines.webp" alt="Thumb">
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <img src="https://www.ultragits.com/assets/img/clients/crisp.webp" alt="Thumb">
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <img src="https://www.ultragits.com/assets/img/clients/client-2.jpg" alt="Thumb">
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <img src="https://www.ultragits.com/assets/img/clients/client-4.jpg" alt="Thumb">
                                </div>
                                <!-- End Single Item -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- End Brand -->

            <!-- Start Fun Factor -->
            <div class="fun-factor-style-one mt-60 mt-xs-50">
                <div class="item-inner">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="500" data-speed="2000">500</div>
                                    <div class="operator">+</div>
                                </div>
                                <span class="medium">Project Done</span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="100" data-speed="2000">100</div>
                                    <div class="operator">%</div>
                                </div>
                                <span class="medium">Positive Rating</span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="500" data-speed="500">500</div>
                                    <div class="operator">+</div>
                                </div>
                                <span class="medium">Happy CLients</span>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 item">
                            <div class="fun-fact">
                                <div class="counter">
                                    <div class="timer" data-to="15" data-speed="2000">15</div>
                                    <div class="operator">+</div>
                                </div>
                                <span class="medium">Certified Experts</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Fun Factor -->

        </div>
    </div>
    <!-- End Brand -->
