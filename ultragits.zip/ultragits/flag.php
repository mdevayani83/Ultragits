<section class="py-5" style="background-color: #f8f9fa;">
  <div class="container text-center">
    <h2 class="mb-5"><strong>Our Clients Worldwide</strong></h2>

    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <!-- Slide 1 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\Uae.jpeg" class="flag-img" alt="UAE">
            <p class="mt-3"><strong>UAE</strong></p>
          </div>
        </div>
        <!-- Slide 2 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\soudi.jpeg" class="flag-img" alt="Saudi Arabia">
            <p class="mt-3"><strong>Saudi Arabia</strong></p>
          </div>
        </div>
        <!-- Slide 3 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\usa.jpeg" class="flag-img" alt="USA">
            <p class="mt-3"><strong>USA</strong></p>
          </div>
        </div>
        <!-- Slide 4 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\uk.jpeg" class="flag-img" alt="UK">
            <p class="mt-3"><strong>UK</strong></p>
          </div>
        </div>
        <!-- Slide 5 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\ned.jpeg" class="flag-img" alt="Netherlands">
            <p class="mt-3"><strong>Netherlands</strong></p>
          </div>
        </div>
        <!-- Slide 6 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\sin.jpeg" class="flag-img" alt="Singapore">
            <p class="mt-3"><strong>Singapore</strong></p>
          </div>
        </div>
        <!-- Slide 7 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\mal.jpeg" class="flag-img" alt="Malaysia">
            <p class="mt-3"><strong>Malaysia</strong></p>
          </div>
        </div>
        <!-- Slide 8 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\aus.jpeg" class="flag-img" alt="Australia">
            <p class="mt-3"><strong>Australia</strong></p>
          </div>
        </div>
        <!-- Slide 9 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\swe.jpeg" class="flag-img" alt="Sweden">
            <p class="mt-3"><strong>Sweden</strong></p>
          </div>
        </div>
        <!-- Slide 10 -->
        <div class="swiper-slide">
          <div class="icon-box">
            <img src="assets\img\germany.jpeg" class="flag-img" alt="Germany">
            <p class="mt-3"><strong>Germany</strong></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Swiper CSS Styles -->
<style>
  .swiper {
    width: 100%;
    height: auto;
  }

  .swiper-wrapper {
    display: flex;
  }

  .swiper-slide {
    flex: 1 0 16.666%; /* 6 slides in a row */
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 10px;
  }

  .icon-box {
    text-align: center;
  }

  .flag-img {
    max-width: 100%;
    height: auto;
    width: 60px; /* Adjust size if needed */
  }

  .swiper-button-next,
  .swiper-button-prev {
    color: black;
  }
</style>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
  const swiper = new Swiper('.mySwiper', {
    slidesPerView: 6, // Shows 6 flags per row
    spaceBetween: 10, // Space between flags
    loop: true, // Enable looping of flags
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });
</script>